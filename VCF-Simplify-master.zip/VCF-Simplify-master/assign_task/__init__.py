__author__ = "Bishwa Giri"
__contributors__ = "Bhuwan Aryal"
__app_name__ = "VCF Simplify"
__version__ = ""
__add_other__ = ""


