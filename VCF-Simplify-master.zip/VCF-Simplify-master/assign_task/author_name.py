#!/home/bin/python3


def print_author_name():
    print("    ## VCF Simplify ## : Python application for parsing VCF files.")
    print("    Author: Bishwa K. Giri")
    print("    Contributors: Bhuwan Aryal")
    print("    Contact: bkgiri@uncg.edu, kirannbishwa01@gmail.com, bhuwanaryal19@gmail.com")
    print()
